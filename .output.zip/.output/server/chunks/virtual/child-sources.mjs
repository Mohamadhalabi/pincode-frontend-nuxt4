const sources = {
    "en": [],
    "ar": []
};

export { sources };
