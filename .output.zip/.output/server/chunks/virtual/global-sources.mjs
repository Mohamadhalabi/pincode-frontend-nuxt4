const sources = [
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/faq",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/faq"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/faq"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/faq"
                    }
                ]
            },
            {
                "loc": "/ar/faq",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/faq"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/faq"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/faq"
                    }
                ]
            },
            {
                "loc": "/cart",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/cart"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/cart"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/cart"
                    }
                ]
            },
            {
                "loc": "/ar/cart",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/cart"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/cart"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/cart"
                    }
                ]
            },
            {
                "loc": "/",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/"
                    }
                ]
            },
            {
                "loc": "/ar",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/"
                    }
                ]
            },
            {
                "loc": "/login",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/login"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/login"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/login"
                    }
                ]
            },
            {
                "loc": "/ar/login",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/login"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/login"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/login"
                    }
                ]
            },
            {
                "loc": "/account",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/account"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/account"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/account"
                    }
                ]
            },
            {
                "loc": "/ar/account",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/account"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/account"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/account"
                    }
                ]
            },
            {
                "loc": "/about-us",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/about-us"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/about-us"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/about-us"
                    }
                ]
            },
            {
                "loc": "/ar/about-us",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/about-us"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/about-us"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/about-us"
                    }
                ]
            },
            {
                "loc": "/contact-us",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/contact-us"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/contact-us"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/contact-us"
                    }
                ]
            },
            {
                "loc": "/ar/contact-us",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/contact-us"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/contact-us"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/contact-us"
                    }
                ]
            },
            {
                "loc": "/checkout",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/checkout"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/checkout"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/checkout"
                    }
                ]
            },
            {
                "loc": "/ar/checkout",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/checkout"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/checkout"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/checkout"
                    }
                ]
            },
            {
                "loc": "/privacy-policy",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/privacy-policy"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/privacy-policy"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/privacy-policy"
                    }
                ]
            },
            {
                "loc": "/ar/privacy-policy",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/privacy-policy"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/privacy-policy"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/privacy-policy"
                    }
                ]
            },
            {
                "loc": "/checkout/success",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/checkout/success"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/checkout/success"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/checkout/success"
                    }
                ]
            },
            {
                "loc": "/ar/checkout/success",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/checkout/success"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/checkout/success"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/checkout/success"
                    }
                ]
            },
            {
                "loc": "/terms-conditions",
                "_sitemap": "en",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/terms-conditions"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/terms-conditions"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/terms-conditions"
                    }
                ]
            },
            {
                "loc": "/ar/terms-conditions",
                "_sitemap": "ar",
                "alternatives": [
                    {
                        "hreflang": "en",
                        "href": "/terms-conditions"
                    },
                    {
                        "hreflang": "ar",
                        "href": "/ar/terms-conditions"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/terms-conditions"
                    }
                ]
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
